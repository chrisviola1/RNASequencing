#! /usr/bin/env python
#packages that come with python
import pandas as pd
import numpy as np
import string
import argparse
import os
import sys
import subprocess
import re

#minimap2 file
from Minimap2_Error_Detection import parse_seqs, minimap2_detection,create_df
#matching file
from Matching_Identification import common_names, MasterMatch, all_counts_total,bed, matching_file

parser = argparse.ArgumentParser()
parser.add_argument("FastaFile1", help="Sequences that need to be aligned in fasta format. Muscle Sequences.")
parser.add_argument("FastaFile2", help="Sequences that need to be aligned in fasta format. Pbdagcon Sequences.")
parser.add_argument("Reference", help="Reference to align sequences against")
parser.add_argument("OutputCsv", nargs='?', const = 1, default="Minimap2_Results.csv", help="The minimap2 error types compiled into a csv file.")
parser.add_argument("Minimap2", nargs='?', const = 1, default=os.getcwd() + "/minimap2", help="Minimap2 application. Assumes minimap2 is in the same directory. Otherwise, enter the directory where minimap2 is located.")

args = parser.parse_args()
fasta1 = args.FastaFile1
fasta2 = args.FastaFile2
ref = args.Reference
minimap2_app = args.Minimap2
result_name = args.OutputCsv

#******************************* Minimap2 error detection **************************************
names, seqs = parse_seqs(fasta1)
error_sequences = minimap2_detection(names, seqs, minimap2_app, ref)
muscle_results = create_df(error_sequences)
print(muscle_results)

names, seqs = parse_seqs(fasta2)
error_sequences = minimap2_detection(names, seqs, minimap2_app, ref)
pbdagcon_results = create_df(error_sequences)
print(pbdagcon_results)

#******************************* New Index **************************************
smaller = ""; larger = ""
if len(pbdagcon_results) >= len(muscle_results):
    smaller = muscle_results
    larger = pbdagcon_results
else:
    smaller = pbdagcon_results
    larger = muscle_results
    temp = fasta1
    fasta1 = fasta2
    fasta2 = temp
    
#******************************* Same Strand IDs **************************************
names = common_names(smaller,larger)
columns = ["Reference NonHP Insertion Positions", "Reference NonHP Deletion Positions", "Reference Substitution Positions", "Reference HP Insertion Positions", "Reference HP Deletion Positions", "Reference Long Insertion Sites", "Reference Long Deletion Sites"]

#******************************* Same Strand Information **************************************
small_data, large_data, all_matches = MasterMatch(smaller, larger, columns)


#******************************* Same Strand Summarize Information *************************************
small_counts, small_mismatch = all_counts_total(small_data)
counts, mismatch = all_counts_total(all_matches)
large_counts, large_mismatch = all_counts_total(large_data)

#******************************* Add Information **************************************
info = {"Name":names, 
        "Similar Mismatches Intersection":mismatch,
        "Mismatches " + fasta1:small_mismatch,
        "Mismatches " + fasta2:large_mismatch,
        "NonHP Insertion Similar from Reference":counts[0],
        "NonHP Deletion Similar from Reference":counts[1],
        "Substitution Similar from Reference":counts[2],
        "HP Insertion Similar from Reference":counts[3],
        "HP Deletion Similar from Reference":counts[4],
        "Long Insertion Similar from Reference":counts[5],
        "Long Deletion Similar from Reference":counts[6],
        "Reference NonHP Insertion Positions":all_matches[0], 
        "Reference NonHP Deletion Positions":all_matches[1],
        "Reference Substitution Positions":all_matches[2], 
        "Reference HP Insertion Positions":all_matches[3],
        "Reference HP Deletion Positions":all_matches[4],
        "Reference Long Insertion Positions":all_matches[5],
        "Reference Long Deletion Positions":all_matches[6]}

#******************************* Bed File Format **************************************
bed(names, all_matches, result_name, fasta1, fasta2)

#******************************* Final File **************************************
df_final = matching_file(names, info, smaller, larger)
print(df_final)
df_final.to_csv(result_name, index = False)























