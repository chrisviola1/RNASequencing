#! /usr/bin/env python
#packages that come with python
import pandas as pd
import numpy as np
import argparse
import os
import sys
import string
import re

#Methods for Results
def ref_insertion_number(insert_str):
    return list(re.findall(r'\d+', insert_str))

def listify(list_str):
    list_str = str(list_str)
    for ch in ['[',']','\'','_',',']:
        if ch in list_str:
            list_str = list_str.replace(ch,'')
    return(list_str.split())

def mergeDictFromList(manyDict):
    if len(manyDict) > 0:
        largeDict = manyDict[0]
        for err in manyDict:
            largeDict.update(err)
    else:
        largeDict = {}
    return largeDict   

def mini_rename(mini):
    progress = 0; MINI_LENGTH = len(mini)
    for i in range(len(mini)):
        old_name = mini.index[i]
        if old_name[-2:] != '.0':
            new_name = old_name[:-1] + '.0\n'
            mini = mini.rename(index={old_name: new_name})
        progress+=1
        percentage = (progress/MINI_LENGTH)*100
        print('Minimap2 Results Renaming Progress [%.5f%%]\r'%percentage, end="")
    print('\n')
    return mini

def common_names(small,large):
    common = []
    indexs = large.index
    progress = 0; SMALL_LENGTH = len(small)
    for i in range(SMALL_LENGTH):
        name = small.index[i]
        if name in indexs:
            common.append(name)
        progress+=1
        percentage = (progress/SMALL_LENGTH)*100
        print('Finding Common Strands Progress [%.5f%%]\r'%percentage, end="")
    print('\n')
    return common

def numbers_dict(hp_nonHp_sub_str, subFlag):
    splitted = re.split('(\d+)',hp_nonHp_sub_str)[1:-1]
    cell = splitted[0]
    cell_dict = {}
    if subFlag == True:
        cell = int(splitted[0])
        cell_dict = {cell:'&'}
    else:
        for elt_index in range(len(splitted)):
            elt = splitted[elt_index]
            if elt == "*" or elt == '^':
                counter = int(splitted[elt_index+1])
                for c in range(counter):
                    cell = cell + elt
        non_digits = re.sub("\d+", "", cell)
        digits = re.findall(r'\d+', cell)
        digits = list(range(int(digits[0]),int(digits[0]) + len(non_digits), 1))
        non_digits = [char for char in non_digits]
        cell_dict = dict(zip(digits, non_digits))
    return cell_dict


def error_type_matching(small_cell, large_cell):
    #MAX_DIFFERENCE = 1
    matches = {}
    #which one is smaller and which one is larger in size
    fewErr = small_cell if len(small_cell) <= len(large_cell) else large_cell
    largeErr = small_cell if fewErr == large_cell else large_cell
 
    #combine dicts
    fewErrDict = mergeDictFromList(fewErr)
    largeErrDict = mergeDictFromList(largeErr)
    
    largePos = list(largeErrDict.keys())
    possMatch = []
    for block in fewErr:
        for pos in block:
            if pos in largePos:
                if fewErrDict[pos] == largeErrDict[pos]:
                    matches[pos] = fewErrDict[pos]
    return matches  

#another method needed for subs
def matches(small,large,col,subFlag):
    col_matches = []
    large_indexs = large.index
    for i in range(len(small)):
        name = small.index[i]
        if name in large_indexs:
            small_dicts = []; large_dicts = []
            small_list = listify(str(small.loc[name][col])); large_list = listify(str(large.loc[name][col]))
            for elt in small_list:
                small_dicts.append(numbers_dict(elt,subFlag))
            for elt in large_list:
                large_dicts.append(numbers_dict(elt,subFlag))
            col_matches.append(error_type_matching(small_dicts, large_dicts))
    return col_matches

def format_match(matches, subFlag):
    i=0
    for match in matches:
        match_transformed = []
        if len(match) > 0:
            if subFlag == True:
                match_transformed = list(match.keys())
            else:
                for values in match.items():
                    match_transformed.append(str(values[0]) + values[1])
        matches[i] = match_transformed; i+=1
    return matches

def majority(dataset, col, subFlag, smaller_indexes):
    col_data = []
    indexs = dataset.index
    for name in smaller_indexes:
        if name in indexs:
            dataset_list = listify(dataset.loc[name][col])
            if len(dataset_list) == 0:
                col_data.append({})
            else:
                all_dicts = []
                for elt in dataset_list:
                    dicts = numbers_dict(elt,subFlag)
                    all_dicts.append(dicts)
                all_dicts = {k:v for dicts in all_dicts for k,v in dicts.items()}
                col_data.append(all_dicts)
    return col_data
  
def all_counts_total(matching_data):
    counts = []
    for error_type in matching_data:
        total = 0
        one_error = [len(row) for row in error_type]
        counts.append(one_error)
    totals = list(np.sum(np.array(counts), axis = 0))
    return counts, totals
    
def bed_format(names, all_matches):
    ref = []; name_bed = []; start = []; end = []; score = []; strand = []; colors = []
    rgb = [(255,0,0), (0,255,0), (0,0,255), (255,128,0), (127,0,255), (0,255,255), (0,128,255)]; color = 0
    for match_type in all_matches:
        row_data = [row if len(row) > 0 else '' for row in match_type]; i = 0
        for elt in row_data:
            if elt != '':
                digits = [int(''.join(re.findall(r'\d', str(pos)))) for pos in elt] #retrieves digits
                consec_digits = ranges(digits) #find consective digits/error block, place in containers
                for tup in consec_digits:
                    ref.append("chr1")
                    name_bed.append("strand_" + str(i))
                    start.append(tup[0]) #start and end, start and end is the same for 1 error
                    end.append(tup[1])
                    score.append(0)
                    strand.append("+")
                    colors.append(str(rgb[color])[1:-1].replace(" ", ""))
            i+=1
        color+=1
    return ref, name_bed, start, end, score, strand, colors

def ranges(nums):
    nums = sorted(set(nums))
    gaps = [[s, e] for s, e in zip(nums, nums[1:]) if s+1 < e]
    edges = iter(nums[:1] + sum(gaps, []) + nums[-1:])
    return list(zip(edges, edges))

def MasterMatch(smaller, larger, columns):
    all_matches = []; small_data = []; large_data = []
    progress = 0; COL_LENGTH = len(columns); i = 0
    for col in columns: #for each column in output
        subFlag = False
        if i == 2: 
            subFlag = True
        small_data.append(format_match(majority(smaller, col, subFlag, smaller.index), subFlag))
        large_data.append(format_match(majority(larger, col, subFlag, smaller.index), subFlag))
        all_matches.append(format_match(matches(smaller,larger,col,subFlag), subFlag))
        progress+=1
        percentage = (progress/COL_LENGTH)*100
        print('Matching Progress [%.5f%%]\r'%percentage, end="")
        i+=1 
    return small_data, large_data, all_matches

def bed(names, all_matches, output, mini1, mini2):
    ref, names_bed, start, end, score, strand, color = bed_format(names, all_matches)
    bed = {"chrom": ref, 
          'chromStart': start,
          'chromEnd': end,
          'name': names_bed,
          'score': score,
          'stand': strand,
          'thickStart': start,
          'thickEnd': end,
          'itemRGB': color} 
    df_bed = pd.DataFrame(bed)

    #write first line
    bed_file = open(r''+ output[:-4] + '.bed', "w")
    bed_file.write("track name=" + "\"" + output[:-4] + "\"" + " description=" + '\"' + mini1 + " and " + mini2 + '\"' + " itemRgb=On" + "\n")
    bed_file.close()

    #add bed data
    bed_file = open(r''+ output[:-4] + '.bed', "a")
    np.savetxt(bed_file, df_bed.values, delimiter = '\t', fmt = "%s")
    bed_file.close()
    
def matching_file(names, info, smaller, larger):
    df = pd.DataFrame(info)
    df = df.set_index("Name")
    identify = 0; identity = ['_file1','_file2']
    for comp_df in [smaller, larger]:
        #comp_df = comp_df.reset_index()
        for column in comp_df:
            comp_df.rename(columns={column:column+identity[identify]}, inplace=True)
        identify+=1

    #add names to beginning of both minimap files
    df.insert(len(df.columns),'Name_file1',names,allow_duplicates = False)
    smaller.insert(len(smaller.columns),'Name_file2',names,allow_duplicates = False)

    #inner join based on names
    df_final = pd.concat([df,smaller,larger], axis=1, join = "inner")

    #delete unecessarry columns and reset indexs to row number
    df_final = df_final.reset_index()
    df_final.dropna(how='all', axis=1)
    return df_final 
